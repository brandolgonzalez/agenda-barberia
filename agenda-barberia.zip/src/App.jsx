import React from 'react';
function App() {
  return <h1>Agenda de Citas para Barbería</h1>;
}
export default App;
